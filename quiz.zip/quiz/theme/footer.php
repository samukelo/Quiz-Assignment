
    <!-- place this script before closing body tag --> 
<!-- place this script before closing body tag --> 
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script>
function validateDate() {
    var dob = document.getElementById("dob").value;
    var enteredDate = new Date(dob);
    var currentDate = new Date();
    var age = currentDate.getFullYear() - enteredDate.getFullYear();

    if (age < 5 || isNaN(enteredDate)) {
        alert("Please enter a valid date of birth. No One Under The Age Of 5 Years Can Participate");
        return false;
    }
    if( age > 120 || isNaN(enteredDate)) {
        alert("Please enter a valid date of birth. No One Over The Age Of 120 Years Can Participate");
        return false;
    }
    return true;
}
</script>
</body>
</html>