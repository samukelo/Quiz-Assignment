<?php 
 require 'config.php';
 include("theme/header.php")
?>
<section class="section-padding"> <br></br>
<div class="row">
    <div class="col-2">
    <p> <br></br> </p>
    </div>
    <div class="col-8" style="border-style: solid;">
    <div class="row justify-content-center">
     <form  method="post"  action="" autocomplete="off" enctype="multipart/form-data" onsubmit="return validateDate()">
      <h2>Personal Details:</h2><br>
     <div class="col-6">
      <label for="exampleFormControlInput1" class="form-label">Full Names</label>
      <input type="text" name="fullname" class="form-control" id="exampleFormControlInput1" placeholder="John Doe" style="border: solid green;" required>
    </div></br>
     <div class="col-6">
      <label for="exampleFormControlInput1" class="form-label">Email address</label>
      <input type="email" name="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" style="border: solid green;" required>
    </div></br>
    <div class="col-6">
      <label for="exampleFormControlInput1" class="form-label">Date Of Birth</label>
      <input type="date" name="dob" id="dob" class="form-control" id="exampleFormControlInput1" placeholder="John Doe" style="border: solid green;" required>
    </div></br>
    <div class="col-6" >
    <label for="exampleFormControlInput1" class="form-label">Contact Number</label>
    <input type="text" name="contact" class="form-control" id="exampleFormControlInput1" placeholder="013 375 2502" style="border: solid green;" required>  
  </div></br></br>
  <h2>What Is Your Favorite Food:</h2><br>
      <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" id="inlineCheckbox1" name="favoritefood[]" value="pizza" style="border: solid green;">
      <label class="form-check-label" for="inlineCheckbox1">Pizza</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" id="inlineCheckbox2" name="favoritefood[]" value="pasta" style="border: solid green;">
      <label class="form-check-label" for="inlineCheckbox2">Pasta</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" id="inlineCheckbox1" name="favoritefood[]" value="papandwors" style="border: solid green;" >
      <label class="form-check-label" for="inlineCheckbox1">Pap and Wors</label>
    </div>
    <div class="form-check form-check-inline">
      <input class="form-check-input" type="checkbox" id="inlineCheckbox2" name="favoritefood[]" value="other" style="border: solid green;" >
      <label class="form-check-label" for="inlineCheckbox2">Other</label>
    </div><br></br><br></br>
    <h5>Please Rate Your Level Of Agreement On A Scale From 1 to 5. With 1 Being "Strongly Agree" And 5 Being "Strongly Disagree":</h5><br>
    <table class="table table-bordered border-danger">
  <thead style="background-color: red;">
    <tr style="background-color: red;" >
      <th scope="col" style="background-color: #0D6EFD;">Hobbies</th>
      <th scope="col" style="background-color: #0D6EFD;">Strongly Agree</th>
      <th scope="col" style="background-color: #0D6EFD;">Agree</th>
      <th scope="col" style="background-color: #0D6EFD;">Neutral</th>
      <th scope="col" style="background-color: #0D6EFD;">Disagree</th>
      <th scope="col" style="background-color: #0D6EFD;">Strongly Disagree</th>      
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row">I Like To Watch Movies</th>
      <td><center><input type="radio" name="q1" value="1" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q1" value="2" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q1" value="3" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q1" value="4" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q1" value="5" style="border: solid green;" required></center></td>
    </tr>
    <tr>
      <th scope="row">I Like To Listen To Radio</th>
      <td><center><input type="radio" name="q2" value="1" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q2" value="2" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q2" value="3" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q2" value="4" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q2" value="5" style="border: solid green;" required></center></td>
    </tr>
    <tr>
      <th scope="row">I Like To Eat Out</th>
      <td><center><input type="radio" name="q3" value="1" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q3" value="2" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q3" value="3" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q3" value="4" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q3" value="5" style="border: solid green;" required></center></td>
    </tr>
    <tr>
      <th scope="row">I Like To Watch Tv</th>
      <td><center><input type="radio" name="q4" value="1" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q4" value="2" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q4" value="3" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q4" value="4" style="border: solid green;" required></center></td>
      <td><center><input type="radio" name="q4" value="5" style="border: solid green;" required></center></td>
    </tr>
  </tbody>
</table><br></br>
<center><input class="btn btn-danger" type="Submit" name="submit" value="Submit" onclick="validateAge()" style="border: solid green;"></center> <br></br>
     </form>
    </div>  
    </div>
    <div class="col-2">
    <p> <br></br> </p>
    </div>
  </div>
</section>
<?php 
  if(isset($_POST['submit'])){
     
    $fullname = mysqli_real_escape_string($con,$_POST['fullname']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $dob = mysqli_real_escape_string($con,$_POST['dob']);
    $contact = mysqli_real_escape_string($con, $_POST['contact']);
    
    //Check Boxes
    $favfood = implode(',',$_POST['favoritefood']);
    
    //Radio Button
    $q1 = mysqli_real_escape_string($con,$_POST['q1']);
    $q2 = mysqli_real_escape_string($con, $_POST['q2']);
    $q3 = mysqli_real_escape_string($con,$_POST['q3']);
    $q4 = mysqli_real_escape_string($con, $_POST['q4']);
 

    //Sql entry
    $insert = "INSERT INTO `userandquiz`(`fullnames`, `email`, `dob`, `contactnumber`, `favoritefood`, `question1`, `question2`, `Question3`, `question4`) 
                                  VALUES ('$fullname','$email','$dob','$contact','$favfood','$q1','$q2','$q3','$q4')";

    $run_insert = mysqli_query($con,$insert);

     if ($run_insert) {
         //targeting `Login Pge because of success message`
       echo "<script>alert('Survey Entered Succesfully success');</script>";
     }
    
    //echo $fullname.'<br>'.$email.'</br>'.$dob.'<br>'.$contact.'<br>'.$favfood.'<br>'.$q1.'<br>'.$q2.'<br>'.$q3.'<br>'.$q4.'<br>';
  }

 include("theme/footer.php");
?>