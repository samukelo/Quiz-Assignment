<?php
//Website Settings
date_default_timezone_set('Africa/Johannesburg');

//Database Settings
$db_servername = "localhost";
$db_username = "root";
$db_password = "";
$db_dbname = "quiz";

$con = mysqli_connect($db_servername,$db_username,$db_password,$db_dbname);
if ($con==false) {
  print"no connection established";
}

?>
