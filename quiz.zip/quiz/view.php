<?php 
 require 'config.php';
 include("theme/header.php");

 //Number of Surveys
$get_numsurveys = "SELECT * FROM `userandquiz`";
$run_numsurveys = mysqli_query($con,$get_numsurveys);
$row_numsurveys = mysqli_fetch_all($run_numsurveys);
$finalnumb = count($row_numsurveys);

//If statement to check if posts are greater than 0
if($finalnumb <= 0){
 //targeting add page 
  echo "<script>alert('No Surveys Available, Please Participate In A Survey');</script>";
 echo"<script>window.open('index.php','_self');</script>";
}
else{
    //********************  Age  *********************************** 
    //Avarage Age
    $get_avgage = "SELECT  AVG(YEAR(CURRENT_DATE) - YEAR(`dob`)) AS age FROM userandquiz";
    $run_avgage = mysqli_query($con,$get_avgage);
    $row_avgage = mysqli_fetch_array($run_avgage);
    $totavg = $row_avgage['age'];

    //Oldest Age
    $get_maxage = "SELECT  MAX(YEAR(CURRENT_DATE) - YEAR(`dob`)) AS maxage FROM userandquiz";
    $run_maxage = mysqli_query($con,$get_maxage);
    $row_maxage = mysqli_fetch_array($run_maxage);
    $totmax = $row_maxage['maxage'];

     //Youngest Age
    $get_minage = "SELECT  MIN(YEAR(CURRENT_DATE) - YEAR(`dob`)) AS minage FROM userandquiz";
    $run_minage = mysqli_query($con,$get_minage);
    $row_minage = mysqli_fetch_array($run_minage);
    $totmin = $row_minage['minage'];

    //********************  Age END ***********************************

    //********************  Percentage Of Favourite Food  ***********************************
    //People Pizza
    //Query For finding food and grouping IT
    $qfood = "SELECT GROUP_CONCAT(`favoritefood`) as favfood FROM userandquiz";
    $runfood = mysqli_query($con,$qfood);
    $row_food = mysqli_fetch_array($runfood);
    $favfood =$row_food['favfood'];
  
    //Variables Exploded for the Loops  
    $pizfood = explode(",", $favfood);
    $pasfood = explode(",", $favfood);
    $pandw = explode(",", $favfood);

    //Searching words
    $search_wordpizza = "pizza";
    $search_wordpasta = "pasta";
    $search_wordpandw = "papandwors";

    // Initialize a counter
    $pizza_count = 0;
    $pasta_count = 0;
    $pandw_count = 0;
    // Iterate through the array and count occurrences of the word
    //Loop for count
    // Pizza Count
    foreach ($pizfood as $piz) {
        if ($piz === $search_wordpizza) {
            $pizza_count++;
        }
    }
    //Pasta Count
    foreach ($pasfood as $pas) {
      if ($pas === $search_wordpasta) {
          $pasta_count++;
      }
    }
    //Pap and Wors Count
    foreach ($pandw as $papw) {
      if ($papw === $search_wordpandw) {
          $pandw_count++;
      }
    }

    //Calculating the Percentage
    //Pizza 
    $totalpizzapecent = 0;
    $totalpizzapecent = $pizza_count / $finalnumb * 100;
    //Pasta
    $totalpastapecent = 0;
    $totalpastapecent = $pasta_count / $finalnumb * 100;
    //Pandw
    $totalpandwpecent = 0;
    $totalpandwpecent = $pandw_count / $finalnumb * 100; 

    //********************  Percentage Of Favourite Food END  ***********************************
    //********************  Hobbies Avarage Start  ***********************************
    //People Watch Movies
    $querypplwatchmovies = "SELECT AVG(`question1`) AS Averagewatchmovies FROM userandquiz;";
    $runpplwatchmovies = mysqli_query($con,$querypplwatchmovies);
    $row_pplwatchmovies = mysqli_fetch_array($runpplwatchmovies);
    $pplwatchmovies = $row_pplwatchmovies['Averagewatchmovies'];
    //People Listen To Radio
    $queryppllistenradio = "SELECT AVG(`question2`) AS Averagelistenradio FROM userandquiz;";
    $runppllistenradio = mysqli_query($con,$queryppllistenradio);
    $row_ppllistenradio = mysqli_fetch_array($runppllistenradio);
    $ppllistenradio = $row_ppllistenradio['Averagelistenradio'];
    //People Eat Out
    $queryppleatout = "SELECT AVG(`question3`) AS Averageeatout FROM userandquiz;";
    $runppleatout = mysqli_query($con,$queryppleatout);
    $row_ppleatout = mysqli_fetch_array($runppleatout);
    $ppleatout = $row_ppleatout['Averageeatout'];
    //People Watch Tv
    $querypplwatchtv = "SELECT AVG(`question4`) AS Averagewatchtv FROM userandquiz;";
    $runpplwatchtv = mysqli_query($con,$querypplwatchtv);
    $row_pplwatchtv = mysqli_fetch_array($runpplwatchtv);
    $pplwatchtv = $row_pplwatchtv['Averagewatchtv'];
    
    ?>
<section class="section-padding"> <br></br>
<div class="row">
    <div class="col-1">
    <p> <br></br> </p>
    </div>
    <div class="col-10" style="border-style: solid;">
    <center><h1>Survey Results</h1></center>
    <div class="row">
    <div class="col-8">
        <p>
            <ul>
                <li style="padding-bottom: 20px;"><h4>Number Of Surveys:</h4></li>
                <li style="padding-bottom: 20px;"><h4>Avarage Age:</h4></li>
                <li style="padding-bottom: 20px;"><h4>Oldest Person Who Participated In Survey:</h4></li>
                <li style="padding-bottom: 20px;"><h4>Youngest Person Who Participated In Survey:</h4></li>
                <br> </br>
                <li style="padding-bottom: 20px;"><h4>Percentage Of People Who Like Pizza:</h4></li>
                <li style="padding-bottom: 20px;"><h4>Percentage Of People Who Like Pasta:</h4></li>
                <li style="padding-bottom: 20px;"><h4>Percentage Of People Who Like Pap and Wors:</h4></li>
                <li><br> </br></li>
                <li style="padding-bottom: 20px;"><h4>People Who To Watch Movies:</h4></li>
                <li style="padding-bottom: 20px;"><h4>People Who To Listen To Radio:</h4></li>
                <li style="padding-bottom: 20px;"><h4>People Who To Eat Out:</h4></li>
                <li style="padding-bottom: 20px;"><h4>People Who To Watch Tv:</h4></li>  
            </ul>
        </p>
    </div>
    <div class="col-4">
    <p>
    <ul>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($finalnumb); ?></h4></li>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($totavg,1); ?></h4></li>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($totmax); ?></h4></li>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($totmin); ?></h4></li>
                <br> </br>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($totalpizzapecent,1); ?>%</h4></li>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($totalpastapecent,1); ?>%</h4></li>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($totalpandwpecent,1); ?>%</h4></li>
                <li><br> </br></li>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($pplwatchmovies,1); ?></h4></li>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($ppllistenradio,1); ?></h4></li>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($ppleatout,1); ?></h4></li>
                <li style="padding-bottom: 20px;"><h4><?php echo number_format($pplwatchtv,1); ?></h4></li>  
            </ul>
        </p>
    </div>
  </div>
    </div>
    <div class="col-1">
      <p> <br></br> </p>
    </div>
  </div>
</section>
<?php 
    }
 include("theme/footer.php");

?>